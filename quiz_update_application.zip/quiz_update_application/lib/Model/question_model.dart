class QuestionModel{
  String question;
  Map<String,bool>answer;

  QuestionModel(this.question,this.answer);
}