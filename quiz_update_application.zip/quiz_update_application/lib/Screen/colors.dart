import 'dart:ui';

class AppColor {
  static final pripmaryColor = Color(0xFF252c4a);
  static final secondaryColor = Color(0xFF117eeb);
}
